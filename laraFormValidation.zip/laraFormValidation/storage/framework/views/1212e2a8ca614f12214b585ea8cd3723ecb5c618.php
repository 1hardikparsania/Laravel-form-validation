<!DOCTYPE html>
<html>
 <head>
  <title>File Uploading in Laravel</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  <br />
  
  <div class="container">
   <h3 >Form Validation Laravel</h3>
   <br />
 
   <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
     Upload Validation Error<br><br>
     <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
    </div>
   <?php endif; ?>
   <?php if($message = Session::get('success')): ?>
   <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong><?php echo e($message); ?></strong>
   </div>
   
   <?php endif; ?>
 
    <form method="POST" action="/addcontact" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
 
        <div class="form-group">
 
            <label class="lable" for="name"> Name </label>
 
            <div class="control">
 
                <input type="text" class="form-control" name="name" placeholder="Name" value="" required>
        
            </div>
       
        </div>

        <div class="form-group">
 
                <label class="lable" for="name"> Email </label>

                <div class="control">

                    <input type="text" class="form-control" name="email" placeholder="Email" value="" required>

                </div>

        </div>

        <div class="form-group">
        
                <label class="lable" for="name"> Number </label>

                <div class="control">

                    <input type="text" class="form-control" name="number" placeholder="Number" value="" required>

                </div>

        </div>

        <div class="form-group">
        
                <label class="lable" for="name"> Password </label>

                <div class="control">

                    <input type="password" class="form-control" name="password" placeholder="Password" value="" required>

                </div>

        </div>

        <div class="form-group">
        
                <label class="lable" for="name"> Confirm Password </label>

                <div class="control">

                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password" value="" required>

                </div>

        </div>
    
       
       
        <div class="form-group">
 
            <div class="control">
 
                <button type="submit" class="btn btn-primary">Add Contact</button>
 
            </div>
 
        </div>
 
    </form> 
 
    </body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laraFormValidation/laraFormValidation/resources/views/contact.blade.php ENDPATH**/ ?>